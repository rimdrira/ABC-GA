## Scalability & fitness
* tests to verify that results are close to the optimal fitness
* tests to record response time of the algorithm 
